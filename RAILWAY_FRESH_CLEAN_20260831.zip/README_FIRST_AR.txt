حزمة Railway جديدة ونظيفة — لا ترقيع على المشروع القديم

هذه الحزمة:
- قراءة GET مفتوحة من البوابة، بلا GATEWAY_SHARED_SECRET وبلا Bearer.
- لا يوجد Rate Limit أو Origin Block داخل التطبيق.
- لا تغيّر مسارات API:
  /healthz
  /v1/health
  /v1/taj/:asset
  /v1/predator/:symbol
  /v1/series/taj/:asset
  /v1/series/predator/:symbol
  /v1/news
  /v1/stream
- الأسعار لا تُعدّل ولا تُصحّح؛ FeedEngine يختار أفضل Tick صالح من المصدر.
- المصادر المتاحة تعمل مع failover داخل البوابة.

قبل حذف مشروع Railway القديم:
احفظ فقط مفاتيح مصادر البيانات التي تستخدمها (TWELVE_DATA_API_KEY وغيرها).
لا تحتاج GATEWAY_SHARED_SECRET في النسخة الجديدة.
