const timeoutFetch = async (url, options={}, ms=2500) => {
  const c=new AbortController(); const t=setTimeout(()=>c.abort(),ms);
  try{return await fetch(url,{...options,signal:c.signal});} finally{clearTimeout(t);}
};
const day = d => d.toISOString().slice(0,10);
export async function fetchNews(symbol,{finnhubKey,benzingaKey}) {
  const jobs=[];
  if(finnhubKey){const to=new Date(),from=new Date(Date.now()-2*86400000);const u=`https://finnhub.io/api/v1/company-news?symbol=${encodeURIComponent(symbol)}&from=${day(from)}&to=${day(to)}&token=${encodeURIComponent(finnhubKey)}`;jobs.push(timeoutFetch(u).then(r=>r.ok?r.json():[]).then(a=>(Array.isArray(a)?a:[]).map(x=>({source:'FINNHUB',id:String(x.id||''),title:x.headline||'',summary:x.summary||'',publishedAt:x.datetime?new Date(x.datetime*1000).toISOString():null,url:x.url||'',symbol}))));}
  if(benzingaKey){const u=`https://api.benzinga.com/api/v2/news?tickers=${encodeURIComponent(symbol)}&pageSize=20`;jobs.push(timeoutFetch(u,{headers:{Authorization:`token ${benzingaKey}`,Accept:'application/json'}}).then(r=>r.ok?r.json():[]).then(a=>(Array.isArray(a)?a:[]).map(x=>({source:'BENZINGA',id:String(x.id||''),title:x.title||'',summary:x.teaser||'',publishedAt:x.created||null,url:x.url||'',symbol}))));}
  const settled=await Promise.allSettled(jobs);const all=settled.flatMap(x=>x.status==='fulfilled'?x.value:[]);
  const seen=new Set();return all.filter(x=>{const k=(x.id||x.url||x.title)+':'+x.source;if(seen.has(k))return false;seen.add(k);return true;}).sort((a,b)=>Date.parse(b.publishedAt||0)-Date.parse(a.publishedAt||0)).slice(0,40);
}
