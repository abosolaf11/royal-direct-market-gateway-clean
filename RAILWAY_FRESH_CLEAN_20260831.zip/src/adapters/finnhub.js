import WebSocket from 'ws';
import { ReconnectController, attachSocketLiveness } from './base.js';
export class FinnhubAdapter {
  constructor(engine,key){this.engine=engine;this.key=key;this.name='finnhub';this.ws=null;this.symbols=new Set();this.reconnect=new ReconnectController(()=>this.connect());engine.registerSource(this.name);}
  available(){return !!this.key;}
  subscribe(channel,symbol){if(channel!=='predator')return;this.symbols.add(symbol.toUpperCase());if(this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({type:'subscribe',symbol:symbol.toUpperCase()}));}
  connect(){if(!this.available()||[WebSocket.OPEN,WebSocket.CONNECTING].includes(this.ws?.readyState))return;const ws=new WebSocket(`wss://ws.finnhub.io?token=${encodeURIComponent(this.key)}`);this.ws=ws;attachSocketLiveness(ws,{onDead:()=>this.engine.sourceError(this.name,'socket_liveness_timeout')});
    ws.on('open',()=>{this.engine.setConnected(this.name,true);this.reconnect.reset();for(const s of this.symbols)ws.send(JSON.stringify({type:'subscribe',symbol:s}));});
    ws.on('message',b=>{try{const m=JSON.parse(b.toString());if(m.type==='trade'&&Array.isArray(m.data))for(const t of m.data)if(t.s&&t.p)this.engine.ingest({channel:'predator',symbol:t.s,price:t.p,ts:Number(t.t)||Date.now(),source:this.name,priceType:'LAST_TRADE'});}catch(e){this.engine.sourceError(this.name,e);}});
    ws.on('error',e=>this.engine.sourceError(this.name,e));ws.on('close',()=>{this.engine.setConnected(this.name,false);this.reconnect.retry();});}
  start(){this.connect();}
}
