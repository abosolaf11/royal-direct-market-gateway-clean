import WebSocket from 'ws';
import { ReconnectController, attachSocketLiveness } from './base.js';
export class AlpacaAdapter {
  constructor(engine,key,secret,feed='iex'){this.engine=engine;this.key=key;this.secret=secret;this.feed=feed;this.name='alpaca';this.ws=null;this.symbols=new Set();this.reconnect=new ReconnectController(()=>this.connect());engine.registerSource(this.name);}
  available(){return !!(this.key&&this.secret);}
  subscribe(channel,symbol){if(channel!=='predator')return;this.symbols.add(symbol.toUpperCase());if(this.ws?.readyState===WebSocket.OPEN)this.sendSub();}
  connect(){if(!this.available()||[WebSocket.OPEN,WebSocket.CONNECTING].includes(this.ws?.readyState))return;const ws=new WebSocket(`wss://stream.data.alpaca.markets/v2/${encodeURIComponent(this.feed)}`);this.ws=ws;attachSocketLiveness(ws,{onDead:()=>this.engine.sourceError(this.name,'socket_liveness_timeout')});
    ws.on('open',()=>{this.engine.setConnected(this.name,true);this.reconnect.reset();ws.send(JSON.stringify({action:'auth',key:this.key,secret:this.secret}));setTimeout(()=>this.sendSub(),150);});
    ws.on('message',b=>{try{const arr=JSON.parse(b.toString());for(const m of (Array.isArray(arr)?arr:[arr]))if(m.T==='t'&&m.S&&m.p)this.engine.ingest({channel:'predator',symbol:m.S,price:m.p,ts:Date.parse(m.t)||Date.now(),source:this.name,priceType:'LAST_TRADE'});}catch(e){this.engine.sourceError(this.name,e);}});
    ws.on('error',e=>this.engine.sourceError(this.name,e));ws.on('close',()=>{this.engine.setConnected(this.name,false);this.reconnect.retry();});}
  sendSub(){if(this.symbols.size&&this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({action:'subscribe',trades:[...this.symbols]}));}
  start(){this.connect();}
}
