import WebSocket from 'ws';
import { ReconnectController, attachSocketLiveness } from './base.js';

export class TwelveDataAdapter {
  constructor(engine,key){this.engine=engine;this.key=key;this.name='twelvedata';this.ws=null;this.subs=new Map();this.reconnect=new ReconnectController(()=>this.connect());engine.registerSource(this.name);}
  available(){return !!this.key;}
  subscribe(channel,symbol,rawSymbol=symbol){this.subs.set(`${channel}:${symbol.toUpperCase()}`,{channel,symbol:symbol.toUpperCase(),rawSymbol});if(this.ws?.readyState===WebSocket.OPEN)this.sendSub();}
  connect(){if(!this.available()||this.ws?.readyState===WebSocket.OPEN||this.ws?.readyState===WebSocket.CONNECTING)return;const ws=new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(this.key)}`);this.ws=ws;attachSocketLiveness(ws,{onDead:()=>this.engine.sourceError(this.name,'socket_liveness_timeout')});
    ws.on('open',()=>{this.engine.setConnected(this.name,true);this.reconnect.reset();this.sendSub();this.hb=setInterval(()=>{if(ws.readyState===WebSocket.OPEN)ws.send(JSON.stringify({action:'heartbeat'}));},10000);});
    ws.on('message',buf=>{try{const m=JSON.parse(buf.toString());if(m.event==='price' || m.price){const raw=(m.symbol||'').toUpperCase();for(const s of this.subs.values())if(String(s.rawSymbol).toUpperCase()===raw)this.engine.ingest({channel:s.channel,symbol:s.symbol,rawSymbol:raw,price:m.price,ts:m.timestamp?Number(m.timestamp)*1000:Date.now(),source:this.name,priceType:'SOURCE_PRICE'});}}catch(e){this.engine.sourceError(this.name,e);}});
    ws.on('error',e=>this.engine.sourceError(this.name,e));ws.on('close',()=>{clearInterval(this.hb);this.engine.setConnected(this.name,false);this.reconnect.retry();});}
  sendSub(){const syms=[...new Set([...this.subs.values()].map(x=>x.rawSymbol))];if(syms.length&&this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({action:'subscribe',params:{symbols:syms.join(',')}}));}
  start(){this.connect();}
}
