import WebSocket from 'ws';
import { ReconnectController, attachSocketLiveness } from './base.js';
export class EodhdAdapter {
  constructor(engine,token){this.engine=engine;this.token=token;this.name='eodhd';this.ws=null;this.symbols=new Set();this.reconnect=new ReconnectController(()=>this.connect());engine.registerSource(this.name);}
  available(){return !!this.token;}
  subscribe(channel,symbol){if(channel!=='predator')return;this.symbols.add(symbol.toUpperCase());if(this.ws?.readyState===WebSocket.OPEN)this.sendSub();}
  connect(){if(!this.available()||[WebSocket.OPEN,WebSocket.CONNECTING].includes(this.ws?.readyState))return;const ws=new WebSocket(`wss://ws.eodhistoricaldata.com/ws/us?api_token=${encodeURIComponent(this.token)}`);this.ws=ws;attachSocketLiveness(ws,{onDead:()=>this.engine.sourceError(this.name,'socket_liveness_timeout')});
    ws.on('open',()=>{this.engine.setConnected(this.name,true);this.reconnect.reset();this.sendSub();});
    ws.on('message',b=>{try{const m=JSON.parse(b.toString());if(m.s&&m.p)this.engine.ingest({channel:'predator',symbol:m.s,price:m.p,ts:Number(m.t)||Date.now(),source:this.name,priceType:'LAST_TRADE'});}catch(e){this.engine.sourceError(this.name,e);}});
    ws.on('error',e=>this.engine.sourceError(this.name,e));ws.on('close',()=>{this.engine.setConnected(this.name,false);this.reconnect.retry();});}
  sendSub(){if(this.symbols.size&&this.ws?.readyState===WebSocket.OPEN)this.ws.send(JSON.stringify({action:'subscribe',symbols:[...this.symbols].join(',')}));}
  start(){this.connect();}
}
