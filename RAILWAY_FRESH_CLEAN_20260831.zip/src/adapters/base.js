export class ReconnectController {
  constructor(connectFn){this.connectFn=connectFn;this.timer=null;this.stopped=false;this.attempt=0;}
  reset(){this.attempt=0;}
  retry(){if(this.stopped||this.timer)return;const delays=[100,250,500,1000,2000,5000];const d=delays[Math.min(this.attempt++,delays.length-1)];this.timer=setTimeout(()=>{this.timer=null;this.connectFn();},d);}
  stop(){this.stopped=true;if(this.timer)clearTimeout(this.timer);}
}

// Detects a socket that remains OPEN but has silently died. It never edits market data.
export function attachSocketLiveness(ws,{intervalMs=15000,missesBeforeKill=2,onDead=()=>{}}={}){
  let misses=0;
  const alive=()=>{misses=0;};
  ws.on('pong',alive); ws.on('message',alive);
  const timer=setInterval(()=>{
    if(ws.readyState!==1)return;
    misses++;
    if(misses>missesBeforeKill){clearInterval(timer);try{onDead();}catch{};try{ws.terminate();}catch{};return;}
    try{ws.ping();}catch{}
  },intervalMs);
  const clear=()=>clearInterval(timer); ws.once('close',clear); ws.once('error',()=>{});
  return clear;
}
