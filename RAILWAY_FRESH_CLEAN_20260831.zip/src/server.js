import http from "node:http";
import { URL } from "node:url";
import { config } from "./config.js";
import { FeedEngine } from "./engine.js";
import { TwelveDataAdapter } from "./adapters/twelvedata.js";
import { AlpacaAdapter } from "./adapters/alpaca.js";
import { EodhdAdapter } from "./adapters/eodhd.js";
import { FinnhubAdapter } from "./adapters/finnhub.js";
import { fetchNews } from "./news.js";
import { TwelveRestFallback } from "./twelve-rest.js";
import { openReadHeaders } from "./lib/security.js";

const engine = new FeedEngine({
  maxAge: config.maxAge,
  quarantineMs: config.quarantineMs,
  maxFutureSkewMs: config.maxFutureSkewMs,
  maxPastSkewMs: config.maxPastSkewMs,
  sourceWeights: config.sourceWeights
});

const adapters = [
  new TwelveDataAdapter(engine, config.twelveKey),
  new AlpacaAdapter(engine, config.alpacaKey, config.alpacaSecret, config.alpacaFeed),
  new EodhdAdapter(engine, config.eodhdToken),
  new FinnhubAdapter(engine, config.finnhubKey)
];

for (const [asset, raw] of Object.entries(config.taj)) {
  adapters[0].subscribe("taj", asset, raw);
}
for (const adapter of adapters) adapter.start();

const twelveRest = new TwelveRestFallback(engine, config.twelveKey);
const streams = new Set();

engine.on("tick", tick => {
  for (const stream of streams) {
    const channelOkay = stream.channel === "all" || stream.channel === tick.channel;
    const symbolOkay = !stream.symbol || stream.symbol === tick.symbol;
    if (channelOkay && symbolOkay) {
      try {
        stream.res.write(`event: tick\ndata: ${JSON.stringify(tick)}\n\n`);
      } catch {}
    }
  }
});

function json(res, status, body) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.end(JSON.stringify(body));
}

function ensurePredator(symbol) {
  for (const adapter of adapters) adapter.subscribe("predator", symbol);
}

async function waitFor(channel, symbol, ms = 650) {
  const existing = engine.snapshot(channel, symbol);
  if (existing) return existing;

  return await new Promise(resolve => {
    const timer = setTimeout(() => {
      engine.off("tick", onTick);
      resolve(engine.snapshot(channel, symbol));
    }, ms);

    const onTick = tick => {
      if (tick.channel === channel && tick.symbol === String(symbol).toUpperCase()) {
        clearTimeout(timer);
        engine.off("tick", onTick);
        resolve(engine.snapshot(channel, symbol));
      }
    };
    engine.on("tick", onTick);
  });
}

async function liveWithRestFallback(channel, symbol, rawSymbol) {
  const live = await waitFor(channel, symbol);
  if (live) return live;

  if (twelveRest.available()) {
    try {
      return await twelveRest.price(channel, symbol, rawSymbol);
    } catch {}
  }
  return engine.snapshot(channel, symbol);
}

function seriesArgs(url) {
  const allowed = new Set(["1min","5min","15min","30min","1h","4h","1day"]);
  const requested = url.searchParams.get("interval");
  const interval = allowed.has(requested) ? requested : "5min";
  const outputsize = Math.max(55, Math.min(240, Number(url.searchParams.get("outputsize")) || 120));
  return {
    interval,
    outputsize,
    timezone: url.searchParams.get("timezone") || "UTC"
  };
}

const server = http.createServer(async (req, res) => {
  openReadHeaders(res);

  if (req.method === "OPTIONS") {
    res.statusCode = 204;
    return res.end();
  }

  if (req.method !== "GET") {
    return json(res, 405, {ok:false, error:"method_not_allowed"});
  }

  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);

  try {
    if (url.pathname === "/healthz") {
      return json(res, 200, {
        ok: true,
        service: "direct-market-gateway-clean",
        mode: "open-read",
        time: new Date().toISOString()
      });
    }

    if (url.pathname === "/v1/health") {
      return json(res, 200, {
        ok: true,
        sources: engine.status(),
        configured: {
          twelvedata: !!config.twelveKey,
          alpaca: !!(config.alpacaKey && config.alpacaSecret),
          eodhd: !!config.eodhdToken,
          finnhub: !!config.finnhubKey,
          benzinga: !!config.benzingaKey
        }
      });
    }

    if (url.pathname.startsWith("/v1/taj/")) {
      const asset = url.pathname.split("/").pop().toLowerCase();
      if (!config.taj[asset]) return json(res, 404, {ok:false, error:"unknown_asset"});

      const tick = await liveWithRestFallback("taj", asset, config.taj[asset]);
      return tick
        ? json(res, 200, {ok:true, tick})
        : json(res, 503, {ok:false, error:"no_live_source", asset});
    }

    if (url.pathname.startsWith("/v1/predator/")) {
      const symbol = url.pathname.split("/").pop().toUpperCase().replace(/[^A-Z0-9.\-]/g, "");
      if (!symbol || symbol.length > 12) return json(res, 400, {ok:false, error:"bad_symbol"});

      ensurePredator(symbol);
      const tick = await liveWithRestFallback("predator", symbol, symbol);
      return tick
        ? json(res, 200, {ok:true, tick})
        : json(res, 503, {ok:false, error:"no_live_source", symbol});
    }

    if (url.pathname.startsWith("/v1/series/taj/")) {
      const asset = url.pathname.split("/").pop().toLowerCase();
      if (!config.taj[asset]) return json(res, 404, {ok:false, error:"unknown_asset"});
      if (!twelveRest.available()) return json(res, 503, {ok:false, error:"series_source_not_configured"});

      const series = await twelveRest.series(config.taj[asset], seriesArgs(url));
      return json(res, 200, {ok:true, channel:"taj", asset, series});
    }

    if (url.pathname.startsWith("/v1/series/predator/")) {
      const symbol = url.pathname.split("/").pop().toUpperCase().replace(/[^A-Z0-9.\-]/g, "");
      if (!symbol || symbol.length > 12) return json(res, 400, {ok:false, error:"bad_symbol"});
      if (!twelveRest.available()) return json(res, 503, {ok:false, error:"series_source_not_configured"});

      const series = await twelveRest.series(symbol, {
        ...seriesArgs(url),
        timezone: "America/New_York"
      });
      return json(res, 200, {ok:true, channel:"predator", symbol, series});
    }

    if (url.pathname === "/v1/news") {
      const symbol = (url.searchParams.get("symbol") || "")
        .toUpperCase()
        .replace(/[^A-Z0-9.\-]/g, "");
      if (!symbol || symbol.length > 12) return json(res, 400, {ok:false, error:"symbol_required"});

      const items = await fetchNews(symbol, config);
      return json(res, 200, {ok:true, symbol, items});
    }

    if (url.pathname === "/v1/stream") {
      const channel = (url.searchParams.get("channel") || "all").toLowerCase();
      if (!["all","taj","predator"].includes(channel)) return json(res, 400, {ok:false, error:"bad_channel"});

      let symbol = (url.searchParams.get("symbol") || "").replace(/[^A-Za-z0-9.\-]/g, "");
      if (channel === "predator" && symbol) {
        symbol = symbol.toUpperCase();
        ensurePredator(symbol);
      }
      if (channel === "taj" && symbol) symbol = symbol.toLowerCase();

      res.statusCode = 200;
      res.setHeader("Content-Type", "text/event-stream; charset=utf-8");
      res.setHeader("Connection", "keep-alive");
      res.setHeader("X-Accel-Buffering", "no");
      res.write(`event: ready\ndata: ${JSON.stringify({ok:true,channel,symbol:symbol||null})}\n\n`);

      const stream = {res, channel, symbol};
      streams.add(stream);
      const ping = setInterval(() => {
        try { res.write(": keepalive\n\n"); } catch {}
      }, 15000);

      req.on("close", () => {
        clearInterval(ping);
        streams.delete(stream);
      });
      return;
    }

    return json(res, 404, {ok:false, error:"not_found"});
  } catch (error) {
    console.error("gateway-error", error?.message || error);
    return json(res, 500, {ok:false, error:"gateway_error"});
  }
});

// No application-side request timeout for normal market reads.
server.requestTimeout = 0;
server.keepAliveTimeout = 65000;

server.listen(config.port, () => {
  console.log(`Direct Market Gateway CLEAN listening on :${config.port}`);
});
