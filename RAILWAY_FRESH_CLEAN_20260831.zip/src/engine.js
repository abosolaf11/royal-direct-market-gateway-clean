import { EventEmitter } from 'node:events';

const validPrice = p => Number.isFinite(Number(p)) && Number(p) > 0;
const clamp = (n,min,max)=>Math.max(min,Math.min(max,n));

export class FeedEngine extends EventEmitter {
  constructor({maxAge, quarantineMs, maxFutureSkewMs=1500, maxPastSkewMs=15000, sourceWeights={}}) {
    super();
    this.maxAge=maxAge; this.quarantineMs=quarantineMs;
    this.maxFutureSkewMs=maxFutureSkewMs; this.maxPastSkewMs=maxPastSkewMs;
    this.sourceWeights=sourceWeights;
    this.ticks=new Map();
    this.health=new Map();
    this.selected=new Map();
  }

  registerSource(name) {
    if (!this.health.has(name)) this.health.set(name,{name,connected:false,lastTickAt:0,lastMessageAt:0,errors:0,invalid:0,stale:0,good:0,quarantinedUntil:0,lastError:null,latencyEmaMs:null});
  }
  setConnected(name,connected){this.registerSource(name);const h=this.health.get(name);h.connected=!!connected;if(connected)h.lastMessageAt=Date.now();}
  touch(name){this.registerSource(name);this.health.get(name).lastMessageAt=Date.now();}
  sourceError(name,error){this.registerSource(name);const h=this.health.get(name);h.errors++;h.lastError=String(error?.message||error||'error').slice(0,180);if(h.errors>=3)h.quarantinedUntil=Date.now()+this.quarantineMs;}
  recover(name){this.registerSource(name);const h=this.health.get(name);h.errors=0;h.invalid=0;h.stale=0;h.lastError=null;h.quarantinedUntil=0;}

  ingest(raw) {
    const source=String(raw.source||''); this.registerSource(source);
    const price=Number(raw.price), ts=Number(raw.ts||Date.now()), receivedAt=Date.now();
    const h=this.health.get(source); h.lastMessageAt=receivedAt;
    if(!raw.channel||!raw.symbol||!source||!validPrice(price)||!Number.isFinite(ts)){
      h.invalid++; if(h.invalid>=3)h.quarantinedUntil=receivedAt+this.quarantineMs; return false;
    }
    const skew=ts-receivedAt;
    if(skew>this.maxFutureSkewMs || skew < -this.maxPastSkewMs){h.stale++; if(h.stale>=5)h.quarantinedUntil=receivedAt+this.quarantineMs; return false;}
    const latency=Math.max(0,receivedAt-ts);
    h.latencyEmaMs=h.latencyEmaMs==null?latency:(h.latencyEmaMs*0.8+latency*0.2);
    h.good++; h.lastTickAt=receivedAt; h.connected=true; h.errors=0; h.invalid=0; h.stale=0;
    if((h.quarantinedUntil||0)<=receivedAt)h.quarantinedUntil=0;
    const tick=Object.freeze({channel:String(raw.channel),symbol:String(raw.symbol).toUpperCase(),price,ts,source,priceType:raw.priceType||'LAST',receivedAt,rawSymbol:raw.rawSymbol||raw.symbol});
    const key=`${tick.channel}:${tick.symbol}`;
    if(!this.ticks.has(key))this.ticks.set(key,new Map());
    this.ticks.get(key).set(source,tick);
    const selected=this.pick(tick.channel,tick.symbol);
    if(selected){const prev=this.selected.get(key);this.selected.set(key,selected);if(!prev||prev.source!==selected.source||prev.ts!==selected.ts||prev.price!==selected.price)this.emit('tick',selected);}
    return true;
  }

  sourceScore(channel,source,t,now){
    const h=this.health.get(source)||{}; const maxAge=this.maxAge[channel]??2000;
    const receiveAge=Math.max(0,now-t.receivedAt); const sourceAge=Math.max(0,now-t.ts);
    const freshness=1-clamp(Math.max(receiveAge,sourceAge)/maxAge,0,1);
    const latencyPenalty=clamp((h.latencyEmaMs||0)/Math.max(maxAge,1),0,1);
    const trust=Number(this.sourceWeights?.[channel]?.[source]??1);
    return freshness*100 + trust*5 - latencyPenalty*5;
  }

  pick(channel,symbol){
    const key=`${channel}:${String(symbol).toUpperCase()}`, map=this.ticks.get(key); if(!map)return null;
    const now=Date.now(), maxAge=this.maxAge[channel]??2000, fresh=[];
    for(const [source,t] of map){
      const h=this.health.get(source)||{}; if((h.quarantinedUntil||0)>now)continue;
      const age=Math.max(0,now-t.ts),receiveAge=Math.max(0,now-t.receivedAt);
      if(age<=maxAge&&receiveAge<=maxAge)fresh.push({t,score:this.sourceScore(channel,source,t,now),age,receiveAge});
    }
    if(!fresh.length)return null;
    // Never average/correct prices. Scoring only chooses WHICH untouched source tick wins.
    fresh.sort((a,b)=>(b.score-a.score)||(a.age-b.age)||(a.receiveAge-b.receiveAge));
    return fresh[0].t;
  }

  snapshot(channel,symbol){const t=this.pick(channel,symbol);return t?{...t,ageMs:Math.max(0,Date.now()-t.ts)}:null;}
  candidates(channel,symbol){
    const key=`${channel}:${String(symbol).toUpperCase()}`,map=this.ticks.get(key),now=Date.now();if(!map)return[];
    return [...map.values()].map(t=>({source:t.source,price:t.price,ts:t.ts,priceType:t.priceType,ageMs:Math.max(0,now-t.ts),selected:this.selected.get(key)?.source===t.source}));
  }
  status(){const now=Date.now();return[...this.health.values()].map(h=>({...h,quarantined:(h.quarantinedUntil||0)>now,latencyEmaMs:h.latencyEmaMs==null?null:Math.round(h.latencyEmaMs)}));}
}
