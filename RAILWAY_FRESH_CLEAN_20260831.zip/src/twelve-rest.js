export class TwelveRestFallback {
  constructor(engine,key){
    this.engine=engine;
    this.key=String(key||'').trim();
    this.name='twelvedata-rest';
    this.priceCache=new Map();
    this.seriesCache=new Map();
    this.inflight=new Map();
    engine.registerSource(this.name);
  }
  available(){return !!this.key;}
  async _json(url,timeoutMs=3500){
    if(!this.available()) throw new Error('twelvedata_rest_not_configured');
    const ctl=new AbortController();
    const timer=setTimeout(()=>ctl.abort(),timeoutMs);
    try{
      const r=await fetch(url,{headers:{accept:'application/json','user-agent':'royal-direct-gateway-v2'},cache:'no-store',signal:ctl.signal});
      const d=await r.json().catch(()=>null);
      if(!r.ok||!d||d.status==='error') throw new Error(d?.message||`twelvedata_http_${r.status}`);
      return d;
    }finally{clearTimeout(timer);}
  }
  async price(channel,symbol,rawSymbol=symbol){
    const key=`${channel}:${String(symbol).toUpperCase()}`;
    const cached=this.priceCache.get(key);
    const now=Date.now();
    if(cached&&now-cached.at<4500){
      this.engine.ingest({channel,symbol,rawSymbol,price:cached.price,ts:now,source:this.name,priceType:'REST_PRICE'});
      return this.engine.snapshot(channel,symbol);
    }
    const inflightKey=`price:${key}`;
    if(this.inflight.has(inflightKey)) return this.inflight.get(inflightKey);
    const p=(async()=>{
      try{
        const u=new URL('https://api.twelvedata.com/price');
        u.searchParams.set('symbol',rawSymbol);
        u.searchParams.set('apikey',this.key);
        const d=await this._json(u,3200);
        const price=Number(d?.price);
        if(!Number.isFinite(price)||price<=0) throw new Error('bad_rest_price');
        const ts=Date.now();
        this.priceCache.set(key,{price,at:ts});
        this.engine.ingest({channel,symbol,rawSymbol,price,ts,source:this.name,priceType:'REST_PRICE'});
        this.engine.recover(this.name);
        return this.engine.snapshot(channel,symbol);
      }catch(e){
        this.engine.sourceError(this.name,e);
        throw e;
      }finally{this.inflight.delete(inflightKey);}
    })();
    this.inflight.set(inflightKey,p);
    return p;
  }
  async series(rawSymbol,{interval='5min',outputsize=120,timezone='UTC'}={}){
    const allowed=new Set(['1min','5min','15min','30min','1h','4h','1day']);
    if(!allowed.has(interval)) interval='5min';
    outputsize=Math.max(55,Math.min(240,Number(outputsize)||120));
    const cacheKey=`${String(rawSymbol).toUpperCase()}|${interval}|${outputsize}|${timezone}`;
    const cached=this.seriesCache.get(cacheKey);
    const now=Date.now();
    if(cached&&now-cached.at<15000) return cached.data;
    const inflightKey=`series:${cacheKey}`;
    if(this.inflight.has(inflightKey)) return this.inflight.get(inflightKey);
    const p=(async()=>{
      try{
        const u=new URL('https://api.twelvedata.com/time_series');
        u.searchParams.set('symbol',rawSymbol);
        u.searchParams.set('interval',interval);
        u.searchParams.set('outputsize',String(outputsize));
        u.searchParams.set('timezone',timezone);
        u.searchParams.set('format','JSON');
        u.searchParams.set('apikey',this.key);
        const d=await this._json(u,4500);
        if(!Array.isArray(d?.values)) throw new Error('no_series_values');
        const values=d.values.map(v=>({
          datetime:String(v?.datetime||''),
          open:Number(v?.open), high:Number(v?.high), low:Number(v?.low), close:Number(v?.close),
          volume:v?.volume==null?null:Number(v.volume)
        })).filter(v=>[v.open,v.high,v.low,v.close].every(Number.isFinite));
        if(values.length<55) throw new Error('insufficient_series');
        const data={symbol:String(rawSymbol),interval,timezone,meta:d.meta||{},values};
        this.seriesCache.set(cacheKey,{at:now,data});
        this.engine.recover(this.name);
        return data;
      }catch(e){
        this.engine.sourceError(this.name,e);
        throw e;
      }finally{this.inflight.delete(inflightKey);}
    })();
    this.inflight.set(inflightKey,p);
    return p;
  }
}
