const num = (name, fallback) => {
  const n = Number(process.env[name]);
  return Number.isFinite(n) ? n : fallback;
};
const jsonMap = (name, fallback={}) => {
  try {
    const x = JSON.parse(process.env[name] || "");
    return x && typeof x === "object" ? x : fallback;
  } catch {
    return fallback;
  }
};

export const config = {
  port: num("PORT", 8787),

  // Source quality/failover only. No client auth, no request block, no rate limiter.
  quarantineMs: num("SOURCE_QUARANTINE_MS", 10000),
  maxFutureSkewMs: num("MAX_FUTURE_SKEW_MS", 1500),
  maxPastSkewMs: num("MAX_PAST_SKEW_MS", 15000),
  maxAge: {
    taj: num("TAJ_MAX_AGE_MS", 1800),
    predator: num("PREDATOR_MAX_AGE_MS", 1200)
  },
  sourceWeights: {
    taj: jsonMap("TAJ_SOURCE_WEIGHTS", {twelvedata: 1}),
    predator: jsonMap("PREDATOR_SOURCE_WEIGHTS", {
      alpaca: 1.05,
      eodhd: 1,
      finnhub: 0.98,
      twelvedata: 0.95
    })
  },

  twelveKey: process.env.TWELVE_DATA_API_KEY || "",
  alpacaKey: process.env.ALPACA_API_KEY || "",
  alpacaSecret: process.env.ALPACA_API_SECRET || "",
  alpacaFeed: process.env.ALPACA_FEED || "iex",
  eodhdToken: process.env.EODHD_API_TOKEN || "",
  finnhubKey: process.env.FINNHUB_API_KEY || "",
  benzingaKey: process.env.BENZINGA_API_KEY || "",

  taj: {
    gold: process.env.TAJ_GOLD_SYMBOL || "XAU/USD",
    wti: process.env.TAJ_WTI_SYMBOL || "WTI/USD",
    gas: process.env.TAJ_GAS_SYMBOL || "XNG/USD",
    sp500: process.env.TAJ_SP500_SYMBOL || "SPX"
  }
};
